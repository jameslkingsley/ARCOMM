class CfgARCMF {
    /*
-----------------------------------------------------------------------------------------------------------------
        BRIEFING CONFIGURATION
        Description: This is the section where you define the text content for the briefing on each team.
        Note: Each text element gets placed on its own line.
        Warning: You must wrap every line in quotes, eg. mission[] = {"This is your mission"};
-----------------------------------------------------------------------------------------------------------------
    */
    class Briefing {
        class BLUFOR {
            logistics[] = {
                "If a single hostage is killed, the mission will be considered at least tie."
            };
            commandersIntent[] = {};
            movementPlan[] = {
                "Feel free to move up close to the compound - you will need to speak face-to-face with the thug leader anyway to negotiate."
            };
            fireSupportPlan[] = {};
            specialTasks[] = {
                "Avoid violence - try to negotiate hostage rescues using the given banana crates. If you feel the situation is not going anywhere, try and neutralise the enemy without harming any hostages."
            };
            mission[] = {
                "- Extract the hostages (at least half to win)<br />- Try to hand over as little crates as possible"
            };
            situation[] = {
                "A lightly armed group of thugs have taken hostages in a nearby building complex, demanding a ransom of bananas. We are part of an elite hostage extraction team tasked with rescuing the hostages safely by using negotiation tactics."
            };
            enemyForces[] = {
                "Thugs"
            };
            friendlyForces[] = {
                "Police"
            };
        };
        class OPFOR {
            logistics[] = {};
            commandersIntent[] = {};
            movementPlan[] = {};
            fireSupportPlan[] = {};
            specialTasks[] = {};
            mission[] = {};
            situation[] = {};
            enemyForces[] = {};
            friendlyForces[] = {};
        };
        class INDFOR {
            logistics[] = {
                "We are allowed to kill any hostages that try to escape or pose a real threat (picking up weapons). We are not allowed to leave the compound!"
            };
            commandersIntent[] = {};
            movementPlan[] = {};
            fireSupportPlan[] = {};
            specialTasks[] = {
                "Avoid violence - try to negotiate with the police to get the banana crates. If you feel the situation is not going anywhere, take the crates forcefully."
            };
            mission[] = {
                "- Keep the hostages secure<br />- Negotiate with the police to obtain crates of bananas<br />- We need at least 150 bananas"
            };
            situation[] = {
                "We have captured hostages and have them held up in a building complex. The police have been sent in to try and rescue them. We are in need of a vast amount of bananas - we need to use the hostages as bargaining chips."
            };
            enemyForces[] = {
                "Police"
            };
            friendlyForces[] = {
                "Thugs"
            };
        };
        class CIVILIAN {
            logistics[] = {};
            commandersIntent[] = {};
            movementPlan[] = {};
            fireSupportPlan[] = {};
            specialTasks[] = {
                "- Try to steal some bananas from the thugs"
            };
            mission[] = {
                "Stay safe and do not try to escape. If you try to escape or pickup weapons the thugs will have full right to kill you."
            };
            situation[] = {};
            enemyForces[] = {};
            friendlyForces[] = {};
        };
        class GAME_MASTER {
            logistics[] = {};
            commandersIntent[] = {};
            movementPlan[] = {};
            fireSupportPlan[] = {};
            specialTasks[] = {};
            mission[] = {};
            situation[] = {};
            enemyForces[] = {};
            friendlyForces[] = {};
        };
    };
    /*
-----------------------------------------------------------------------------------------------------------------
        MARKER CONFIGURATION
        Description: This is the section where you define the settings for group map markers.
-----------------------------------------------------------------------------------------------------------------
    */
    class Markers {
        class BLUFOR {
            enableGroupMarkers = true;
            fireteamMemberFadeDistance = 100;
        };
        class OPFOR {
            enableGroupMarkers = true;
            fireteamMemberFadeDistance = 100;
        };
        class INDFOR {
            enableGroupMarkers = false;
            fireteamMemberFadeDistance = 100;
        };
    };
    /*
-----------------------------------------------------------------------------------------------------------------
        ACRE RADIO CONFIGURATION
        Description: This is the section where you define which radios particular loadouts get for each side.
        Notes:
            1. If you want a radio to be assigned to all units, put "all".
            2. Possible language values are "english", "greek" and "russian".
-----------------------------------------------------------------------------------------------------------------
    */
    class ACRE {
        class BLUFOR {
            languages[] = {"english","russian","greek"};
            AN_PRC_343[] = {"all"};
            AN_PRC_148[] = {"co", "dc", "ftl", "vc", "mmgtl", "mattl", "fac", "m"};
            AN_PRC_152[] = {"co", "dc", "cp", "p", "vc", "mmgtl", "mattl", "mtrl", "fac"};
            AN_PRC_117F[] = {};
            AN_PRC_77[] = {};
        };
        class OPFOR {
            languages[] = {"english","russian","greek"};
            AN_PRC_343[] = {"all"};
            AN_PRC_148[] = {"co", "dc", "ftl", "vc", "mmgtl", "mattl", "fac", "m"};
            AN_PRC_152[] = {"co", "dc", "cp", "p", "vc", "mmgtl", "mattl", "mtrl", "fac"};
            AN_PRC_117F[] = {};
            AN_PRC_77[] = {};
        };
        class INDFOR {
            languages[] = {"english","russian","greek"};
            AN_PRC_343[] = {};
            AN_PRC_148[] = {};
            AN_PRC_152[] = {};
            AN_PRC_117F[] = {};
            AN_PRC_77[] = {};
        };
    };
    /*
-----------------------------------------------------------------------------------------------------------------
        AI GEAR CONFIGURATION
        Description: This is the section where you define loadouts for the AI teams.
        Notes:
            1. AI loadouts are randomized based on their probability settings.
                a. Probability between 0 and 1 (0 = 0%, 1 = 100%).
                b. If array elements don't add up to 1 then ranges are recalculated proportionally.
                c. To remove a default item use an empty string.
            2. This is an array of classnames.
            3. ARC_AI disables the use of grenades and grenade launchers for AI units.
            4. This handles any spawning of units whether it's Zeus, MCC or script.
            5. prioritizeTracerMags - true will only add tracer magazines if available (reverts to standard if none).
            6. removeMedicalItems - true will remove all ACE medical items.
            7. removeNightVision - true will remove all night vision goggles
            8. enabled - true will enable the custom AI gear for the given team, false will not
        Example:
            headgear[] = {
                {"H_HelmetSpecB_snakeskin", 0.8},
                {"", 0.2} // 20% chance to remove all headgear
            };
            rifles[] = {
                {"rhs_weap_m4a1_carryhandle", 0.75},
                {"rhs_weap_m249_pip_L", 0.25}
            };
-----------------------------------------------------------------------------------------------------------------
    */
    class AI {
        class Gear {
            class BLUFOR {
                enabled = false;
                removeNightVision = true;
                removeMedicalItems = true;
                prioritizeTracerMags = true;
                uniforms[] = {};
                vests[] = {};
                headgear[] = {};
                goggles[] = {};
                backpacks[] = {};
                faces[] = {};
                voices[] = {};
                rifles[] = {};
                launchers[] = {};
                attachments[] = {};
            };
            class OPFOR {
                enabled = false;
                removeNightVision = true;
                removeMedicalItems = true;
                prioritizeTracerMags = true;
                uniforms[] = {};
                vests[] = {};
                headgear[] = {};
                goggles[] = {};
                backpacks[] = {};
                faces[] = {};
                voices[] = {};
                rifles[] = {};
                launchers[] = {};
                attachments[] = {};
            };
            class INDFOR {
                enabled = false;
                removeNightVision = true;
                removeMedicalItems = true;
                prioritizeTracerMags = true;
                uniforms[] = {};
                vests[] = {};
                headgear[] = {};
                goggles[] = {};
                backpacks[] = {};
                faces[] = {};
                voices[] = {};
                rifles[] = {};
                launchers[] = {};
                attachments[] = {};
            };
            class CIVILIAN {
                enabled = false;
                removeNightVision = true;
                removeMedicalItems = true;
                prioritizeTracerMags = true;
                uniforms[] = {};
                vests[] = {};
                headgear[] = {};
                goggles[] = {};
                backpacks[] = {};
                faces[] = {};
                voices[] = {};
                rifles[] = {};
                launchers[] = {};
                attachments[] = {};
            };
        };
    };
};
