class Extended_Init_Eventhandlers {
    class CAManBase {
        ARC_applyLoadout = "_this call ARC_fnc_applyLoadout";
    };
};