class CfgSandbox {
    class abel {
        startingPosition[] = {8017.67,9710.44,0};
        camouflage = "mtp";
    };
    class Altis {
        startingPosition[] = {26779.7,24675.2,0};
        camouflage = "mtp";
    };
    class Bootcamp_ACR {
        startingPosition[] = {1686.72,102.895,0};
        camouflage = "woodland";
    };
    class Bozcaada {
        startingPosition[] = {8052.82,10815.7,0};
        camouflage = "mtp";
    };
    class cain {
        startingPosition[] = {6723.41,3681.76,0};
        camouflage = "mtp";
    };
    class Chernarus {
        startingPosition[] = {4696.44,2600.68,0};
        camouflage = "woodland";
    };
    class Chernarus_Summer {
        startingPosition[] = {4696.44,2600.68,0};
        camouflage = "woodland";
    };
    class Desert_E {
        startingPosition[] = {508.152,1001.19,0};
        camouflage = "desert";
    };
    class Desert_Island {
        startingPosition[] = {9733.54,3821.84,0};
        camouflage = "desert";
    };
    class eden {
        startingPosition[] = {4871.1,11800.4,0};
        camouflage = "mtp";
    };
    class fallujah {
        startingPosition[] = {7974.31,1823.33,0};
        camouflage = "desert";
    };
    class FDF_Isle1_a {
        startingPosition[] = {7945.72,4166.32,0};
        camouflage = "woodland";
    };
    class IsolaDiCapraia {
        startingPosition[] = {1223.05,8998.29,0};
        camouflage = "mtp";
    };
    class mbg_celle2 {
        startingPosition[] = {7775.92,1381.63,0};
        camouflage = "woodland";
    };
    class MCN_Aliabad {
        startingPosition[] = {1764.62,5779.12,0};
        camouflage = "mtp";
    };
    class namalsk {
        startingPosition[] = {6273.84,9361.61,0};
        camouflage = "woodland";
    };
    class noe {
        startingPosition[] = {9053.75,12546,0};
        camouflage = "mtp";
    };
    class Porto {
        startingPosition[] = {1662.55,2307.03,0};
        camouflage = "mtp";
    };
    class ProvingGrounds_PMC {
        startingPosition[] = {1169.49,1815.44,0};
        camouflage = "woodland";
    };
    class Sara {
        startingPosition[] = {9544.64,9870.59,0};
        camouflage = "woodland";
    };
    class Shapur_BAF {
        startingPosition[] = {739.331,364.626,0};
        camouflage = "desert";
    };
    class Stratis {
        startingPosition[] = {1903.85,5743.62,0};
        camouflage = "mtp";
    };
    class Takistan {
        startingPosition[] = {5798.65,11209.9,0};
        camouflage = "desert";
    };
    class Tanoa {
        startingPosition[] = {11813.2,13071.4,0};
        camouflage = "woodland";
    };
    class Thirsk {
        startingPosition[] = {723.811,518.21,0};
        camouflage = "woodland";
    };
    class ThirskW {
        startingPosition[] = {723.811,518.21,0};
        camouflage = "winter";
    };
    class torabora {
        startingPosition[] = {10060.9,9922.96,0};
        camouflage = "mtp";
    };
    class utes {
        startingPosition[] = {3557.51,3540.61,0};
        camouflage = "woodland";
    };
    class VR {
        startingPosition[] = {1770.84,1782.24,0};
        camouflage = "default";
    };
    class vt5 {
        startingPosition[] = {238.369,457.755,0};
        camouflage = "woodland";
    };
    class WL_WRoute191 {
        startingPosition[] = {4676.72,364.16,0};
        camouflage = "winter";
    };
    class Woodland_ACR {
        startingPosition[] = {850.789,7455.59,0};
        camouflage = "woodland";
    };
    class Zargabad {
        startingPosition[] = {3562.25,4093.43,0};
        camouflage = "desert";
    };
};
