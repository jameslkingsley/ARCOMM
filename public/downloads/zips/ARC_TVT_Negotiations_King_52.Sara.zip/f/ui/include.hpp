// Used IDC's
// 2000

#include "defines.hpp"
#include "gear\dialog.hpp"
#include "groups\dialog.hpp"
