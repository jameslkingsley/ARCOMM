class CfgSandboxThemes {};
