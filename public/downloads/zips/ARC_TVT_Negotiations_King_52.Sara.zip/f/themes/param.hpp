class arc_param_theme {
    title = "Loadout Preset";
    values[] = {0};
    texts[] = {"Default"};
    default = 0;
    code = "arc_param_theme = ['Default'] select %1";
};
